// For some reason, platformio refuses to compile unless at least one .cpp file is present in this directory.
// This file is not used in the build process, but is required to satisfy platformio.